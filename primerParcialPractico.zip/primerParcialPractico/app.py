from flask import Flask, render_template, jsonify, redirect, url_for
import csv
import os

app = Flask(__name__)

def cargar_productos():
    productos = []
    with open('productos.csv', 'r', encoding='utf-8') as archivo:
        lector = csv.DictReader(archivo)
        for i, fila in enumerate(lector, 1):
            productos.append({
                "id": i,
                "nombre": fila['nombre_producto'],
                "precio": float(fila['precio'])
            })
    return productos

products = cargar_productos()

@app.route('/')
def index():
    return redirect(url_for('productos'))

@app.route('/productos')
def productos():
    return render_template('productos.html', productos=products)

@app.route('/productos/<int:id>')
def detalle_producto(id):
    producto = next((p for p in products if p['id'] == id), None)
    if producto:
        return render_template('detalle_producto.html', producto=producto)
    return "Producto no encontrado", 404

@app.route('/api/productos')
def api_productos():
    return jsonify(products)

if __name__ == '__main__':
    app.run(debug=True) 